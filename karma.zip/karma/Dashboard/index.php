<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.html");
    exit();
}

// Nome utente esempio, puoi prenderlo dal DB
$username = $_SESSION['username'] ?? 'Cliente';

// Array dei servizi (solo uno per ora)
$services = [
    [
        "title" => "Menu Online",
        "desc" => "",
        "icon" => "bi-shop", // icona negozio/ristorante
        "link" => "menu/menu.php",
        "color" => "primary"
    ]
];
?>

<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Menu Online</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body { background-color: #121212; color: #fff; }
    .navbar, .card { background-color: #1e1e1e; }
    .card:hover { transform: scale(1.03); transition: 0.3s; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
    .logout-btn { color: #fff; background-color: #ff4b4b; }
    .logout-btn:hover { background-color: #e03a3a; }
    .service-icon { font-size: 2.5rem; margin-bottom: 15px; }
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark px-4">
    <a class="navbar-brand fw-bold" href="#">Dashboard</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <?php foreach($services as $service): ?>
                <li class="nav-item"><a class="nav-link" href="<?= $service['link'] ?>"><?= $service['title'] ?></a></li>
            <?php endforeach; ?>
            <li class="nav-item"><a class="btn logout-btn ms-3" href="../logout.php">Logout</a></li>
        </ul>
    </div>
</nav>

<!-- Header -->
<!--<div class="container mt-4 text-center">
    <h1>Benvenuto</h1>
</div>-->

<!-- Servizi -->
<div class="container mt-5">
    <div class="row justify-content-center">
        <?php foreach($services as $service): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card p-4 text-center">
                <i class="bi <?= $service['icon'] ?> service-icon text-<?= $service['color'] ?>"></i>
                <h3 style="color: white;"><?= $service['title'] ?></h3>
                <p><?= $service['desc'] ?></p>
                <a href="<?= $service['link'] ?>" class="btn btn-<?= $service['color'] ?>">Accedi al servizio</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
