<?php
$servername = "localhost";
$dbname = "karma";
$dbusername = "root";
$dbpassword = "";

// Connessione
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}
?>
