<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.html");
    exit();
}
require_once "../../config.php";

$upload_dir = "image/";

// --- Aggiungi Piatto ---
if (isset($_POST['add'])) {
    $nome_it = $_POST['nome_it'];
    $nome_en = $_POST['nome_en'];
    $descrizione_it = $_POST['descrizione_it'];
    $descrizione_en = $_POST['descrizione_en'];
    $prezzo = $_POST['prezzo'];
    $categoria = $_POST['categoria'];
    $immagine = null;

    if (!empty($_FILES['immagine']['name'])) {
        $file_name = time() . "_" . basename($_FILES['immagine']['name']);
        $target = $upload_dir . $file_name;
        if (move_uploaded_file($_FILES['immagine']['tmp_name'], $target)) {
            $immagine = $file_name;
        } else {
            echo "Errore: impossibile caricare l'immagine.";
        }
    }

    $stmt = $conn->prepare("INSERT INTO piatti (nome_it,nome_en,descrizione_it,descrizione_en,prezzo,categoria,immagine) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssss", $nome_it,$nome_en,$descrizione_it,$descrizione_en,$prezzo,$categoria,$immagine);
    $stmt->execute();
    $stmt->close();
    header("Location: menu.php");
    exit();
}

// --- Modifica Piatto ---
if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $nome_it = $_POST['nome_it'];
    $nome_en = $_POST['nome_en'];
    $descrizione_it = $_POST['descrizione_it'];
    $descrizione_en = $_POST['descrizione_en'];
    $prezzo = $_POST['prezzo'];
    $categoria = $_POST['categoria'];

    if (!empty($_FILES['immagine']['name'])) {
        $file_name = time() . "_" . basename($_FILES['immagine']['name']);
        $target = $upload_dir . $file_name;
        move_uploaded_file($_FILES['immagine']['tmp_name'], $target);
        $conn->query("UPDATE piatti SET immagine='$file_name' WHERE id=$id");
    }

    $stmt = $conn->prepare("UPDATE piatti SET nome_it=?, nome_en=?, descrizione_it=?, descrizione_en=?, prezzo=?, categoria=? WHERE id=?");
    $stmt->bind_param("ssssssi", $nome_it, $nome_en, $descrizione_it, $descrizione_en, $prezzo, $categoria, $id);
    $stmt->execute();
    $stmt->close();
    header("Location: menu.php");
    exit();
}

// --- Elimina Piatto ---
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $res = $conn->query("SELECT immagine FROM piatti WHERE id=$id");
    if ($r = $res->fetch_assoc()) {
        if ($r['immagine'] && file_exists($upload_dir . $r['immagine'])) {
            unlink($upload_dir . $r['immagine']);
        }
    }
    $conn->query("DELETE FROM piatti WHERE id=$id");
    header("Location: menu.php");
    exit();
}

// --- Attiva/Disattiva ---
if (isset($_GET['toggle'])) {
    $id = $_GET['toggle'];
    $conn->query("UPDATE piatti SET disponibile = NOT disponibile WHERE id=$id");
    header("Location: menu.php");
    exit();
}

$piatti = $conn->query("SELECT * FROM piatti ORDER BY categoria, nome_it");
?>

<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestione Menu Online</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
<style>
    body { background-color: #121212; color: #fff; }
    .navbar, .table, .modal-content { background-color: #1e1e1e; color: #fff; }
    img.piatto-img { width: 80px; height: 80px; object-fit: cover; border-radius: 8px; cursor: pointer; transition: transform 0.2s; }
    img.piatto-img:hover { transform: scale(1.1); }
    input#searchInput {
        box-shadow: 0 0 10px rgba(0,255,200,0.3);
        transition: box-shadow 0.3s ease;
    }
    input#searchInput:focus {
        box-shadow: 0 0 15px rgba(0,255,200,0.5);
        outline: none;
    }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg  navbar-dark px-4">
    <a class="navbar-brand fw-bold" href="../index.php">← Torna alla Dashboard</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse ms-auto" id="navbarContent">
        <div class="d-flex gap-2 ms-auto mt-2 mt-lg-0">
            <a class="btn btn-outline-info" href="../../menu-online.php" target="_blank">
                <i class="bi bi-journal-text"></i> Mostra Menu Online
            </a>
            <a class="btn btn-danger" href="../logout.php">Logout</a>
        </div>
    </div>
</nav>


<div class=" mt-3">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="input-group w-50">
            <span class="input-group-text bg-dark text-light border-secondary"><i class="bi bi-search"></i></span>
            <input type="text" id="searchInput" class="form-control bg-dark text-light border-secondary" placeholder="Cerca per nome o categoria...">
        </div>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addModal">
            <i class="bi bi-plus-lg"></i> Aggiungi Piatto
        </button>
    </div>
    
    <table class="table table-dark table-hover align-middle mb-0">
        <thead>
            <tr>
                <th>Immagine</th>
                <th>Nome (IT/EN)</th>
                <th>Descrizione (IT/EN)</th>
                <th>Prezzo (€)</th>
                <th>Categoria</th>
                <th>Stato</th>
                <th>Azioni</th>
            </tr>
        </thead>
        <tbody>
       <?php while($r = $piatti->fetch_assoc()): ?>
    <tr>
        <td>
            <?php if ($r['immagine']): ?>
                <img src="<?= $upload_dir . $r['immagine'] ?>" class="piatto-img" alt="Immagine piatto">
            <?php else: ?>
                <span class="text-muted">—</span>
            <?php endif; ?>
        </td>
        <td><?= htmlspecialchars($r['nome_it']) ?> / <?= htmlspecialchars($r['nome_en']) ?></td>
        <td title="<?= htmlspecialchars($r['descrizione_it']) ?> / <?= htmlspecialchars($r['descrizione_en']) ?>">
            <?= !empty($r['descrizione_it']) ? (strlen($r['descrizione_it']) > 30 ? htmlspecialchars(substr($r['descrizione_it'],0,30)) . "…" : htmlspecialchars($r['descrizione_it'])) : '-' ?>
            /
            <?= !empty($r['descrizione_en']) ? (strlen($r['descrizione_en']) > 30 ? htmlspecialchars(substr($r['descrizione_en'],0,30)) . "…" : htmlspecialchars($r['descrizione_en'])) : '-' ?>
        </td>
        <td><?= htmlspecialchars($r['prezzo']) ?></td>
        <td><?= htmlspecialchars($r['categoria']) ?></td>
        <td>
            <span class="badge <?= $r['disponibile'] ? 'bg-success' : 'bg-secondary' ?>">
                <?= $r['disponibile'] ? 'Disponibile' : 'Non disponibile' ?>
            </span>
        </td>
        <td>
            <a href="?toggle=<?= $r['id'] ?>" class="btn btn-warning btn-sm"><i class="bi bi-power"></i></a>
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $r['id'] ?>"><i class="bi bi-pencil"></i></button>
            <a href="?delete=<?= $r['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Eliminare questo piatto?')"><i class="bi bi-trash"></i></a>
        </td>
    </tr>
            <!-- Modal Modifica -->
            <div class="modal fade" id="editModal<?= $r['id'] ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="modal-header">
                                <h5 class="modal-title">Modifica Piatto</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                <div class="mb-3">
                                    <label>Nome IT</label>
                                    <input type="text" name="nome_it" class="form-control" value="<?= htmlspecialchars($r['nome_it']) ?>" >
                                </div>
                                <div class="mb-3">
                                    <label>Nome EN</label>
                                    <input type="text" name="nome_en" class="form-control" value="<?= htmlspecialchars($r['nome_en']) ?>" >
                                </div>
                                <div class="mb-3">
                                    <label>Descrizione IT</label>
                                    <textarea name="descrizione_it" class="form-control"><?= htmlspecialchars($r['descrizione_it']) ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label>Descrizione EN</label>
                                    <textarea name="descrizione_en" class="form-control"><?= htmlspecialchars($r['descrizione_en']) ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label>Prezzo (€)</label>
                                    <input type="text"  name="prezzo" class="form-control" value="<?= htmlspecialchars($r['prezzo']) ?>" >
                                </div>
                                <div class="mb-3">
                                    <label>Categoria</label>
                                    <select name="categoria" class="form-control" >
                                        <option value="Antipasti" <?= $r['categoria'] == 'Antipasti' ? 'selected' : '' ?>>Antipasti</option>
                                        <option value="Primi" <?= $r['categoria'] == 'Primi' ? 'selected' : '' ?>>Primi</option>
                                        <option value="Secondi" <?= $r['categoria'] == 'Secondi' ? 'selected' : '' ?>>Secondi</option>
                                        <option value="Contorni" <?= $r['categoria'] == 'Contorni' ? 'selected' : '' ?>>Contorni</option>
                                        <option value="Dolci" <?= $r['categoria'] == 'Dolci' ? 'selected' : '' ?>>Dolci</option>
                                        <option value="Bevande" <?= $r['categoria'] == 'Bevande' ? 'selected' : '' ?>>Bevande</option>
                                        <option value="Crudities/Ostriche" <?= $r['categoria'] == 'Crudities/Ostriche' ? 'selected' : '' ?>>Crudities/Ostriche</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label>Nuova Immagine (opzionale)</label>
                                    <input type="file" name="immagine" class="form-control">
                                </div>
                                <?php if ($r['immagine']): ?>
                                    <div class="text-center">
                                        <img src="<?= $upload_dir . $r['immagine'] ?>" class="piatto-img mt-2">
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" name="edit" class="btn btn-primary">Salva modifiche</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
<?php endwhile; ?>
        </tbody>
    </table>
</div>
    

<!-- Modal Aggiungi -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title">Aggiungi Piatto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Nome IT</label>
                        <input type="text" name="nome_it" class="form-control" >
                    </div>
                    <div class="mb-3">
                        <label>Nome EN</label>
                        <input type="text" name="nome_en" class="form-control" >
                    </div>
                    <div class="mb-3">
                        <label>Descrizione IT</label>
                        <textarea name="descrizione_it" class="form-control"></textarea>
                    </div>
                    <div class="mb-3">
                        <label>Descrizione EN</label>
                        <textarea name="descrizione_en" class="form-control"></textarea>
                    </div>
                    <div class="mb-3">
                        <label>Prezzo (€)</label>
                        <input type="text"  name="prezzo" class="form-control" >
                    </div>
                    <div class="mb-3">
                        <label>Categoria</label>
                        <select name="categoria" class="form-control" >
                            <option value="">Seleziona una categoria</option>
                            <option value="Antipasti">Antipasti</option>
                            <option value="Primi">Primi</option>
                            <option value="Secondi">Secondi</option>
                            <option value="Contorni">Contorni</option>
                            <option value="Dolci">Dolci</option>
                            <option value="Bevande">Bevande</option>
                            <option value="Crudities/Ostriche">Crudities/Ostriche</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Immagine</label>
                        <input type="file" name="immagine" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="add" class="btn btn-success">Aggiungi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- 🔍 Script Ricerca Dinamica -->
<script>
document.getElementById("searchInput").addEventListener("keyup", function() {
    let filter = this.value.toLowerCase();
    let rows = document.querySelectorAll("table tbody tr");

    rows.forEach(row => {
        let nome = row.cells[1]?.innerText.toLowerCase() || "";
        let categoria = row.cells[4]?.innerText.toLowerCase() || "";
        if (nome.includes(filter) || categoria.includes(filter)) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
});
</script>

</body>
</html>
