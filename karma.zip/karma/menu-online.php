<?php
require_once "config.php"; 
$upload_dir = "dashboard/menu/image/"; 

// Recupera solo i piatti disponibili
$piatti = $conn->query("SELECT * FROM piatti WHERE disponibile = 1");

// 👉 Definisci l’ordine delle categorie con traduzione inglese
$ordine_categorie = [
    "Crudities/Ostriche" => "Crudités/Oysters",
    "Antipasti" => "Starters",
    "Primi" => "First Courses",
    "Secondi" => "Main Courses",
    "Contorni" => "Side Dishes",
    "Dolci del giorno" => "Desserts of the Day"
];

// Raggruppa i piatti per categoria
$menu = [];
while ($r = $piatti->fetch_assoc()) {
    $menu[$r['categoria']][] = $r;
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Menù - Karma</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Great+Vibes&family=Montserrat:wght@400;600&display=swap');
body { background-color: #ffc0cb; font-family: 'Montserrat', sans-serif; color: #111; margin: 0; padding: 0; }
header { text-align: center; padding: 2.5rem 1rem 1rem; }
header h1 { font-family: 'Great Vibes', cursive; font-size: 3rem; color: #000; margin: 1rem 0 0.3rem; }
main { max-width: 750px; margin: 2rem auto; background: #fff; border-radius: 20px; padding: 2rem; box-shadow: 0 4px 25px rgba(0,0,0,0.15); animation: fadeIn 0.8s ease-in; }
h2 { font-family: 'Great Vibes', cursive; text-align: center; color: #ff69b4; font-size: 2rem; margin: 1.5rem 0 1rem; position: relative; transition: 0.3s; }
h2::after { content: ""; width: 60px; height: 3px; background: #ff69b4; display: block; margin: 0.5rem auto 0; border-radius: 2px; }
.dish { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px dotted #ddd; padding: 1rem 0; flex-wrap: wrap; gap: 1rem; }
.dish:last-child { border-bottom: none; }
.dish img { width: 100px; height: 80px; object-fit: cover; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); cursor: pointer; transition: transform 0.2s; }
.dish img:hover { transform: scale(1.05); }
.dish-info { flex: 1; min-width: 180px; }
.dish-name { font-weight: 600; font-size: 1rem; color: #222; }
.dish-desc { font-size: 0.9rem; color: #555; margin-top: 0.2rem; }
.allergens { font-size: 0.8rem; color: #777; margin-top: 0.3rem; display: flex; align-items: center; gap: 4px; }
.allergens::before { content: "⚠️"; }
.price { color: #ff69b4; font-weight: bold; min-width: 60px; text-align: right; }
.language-btn { position: fixed; top: 15px; right: 15px; background: #ff69b4; color: #fff; border: none; padding: 8px 12px; border-radius: 5px; cursor: pointer; z-index: 1000; }
.language-btn:hover { background: #ff4b9a; }
.lightbox { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); justify-content:center; align-items:center; z-index:999; }
.lightbox img { max-width:90%; max-height:90%; border-radius:12px; }
.menu-notes { background: #fff0f5; border-radius: 12px; padding: 1rem 1.5rem; margin: 2rem auto; max-width: 750px; font-size: 0.9rem; color: #333; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.menu-notes p { margin: 0.4rem 0; }
@keyframes fadeIn { from {opacity:0; transform: translateY(10px);} to {opacity:1; transform: translateY(0);} }
@media (max-width: 600px) { main { padding: 1rem; margin: 1rem; } .dish img { width: 60px; height: 50px; } .price { min-width: 50px; } }
</style>
</head>
<body>

<button class="language-btn" id="toggleLang">EN/IT</button>

<header>
  <h1 id="restaurant-name">Karma</h1>
</header>

<main id="menu-content">
<?php
foreach ($ordine_categorie as $cat_it => $cat_en) :
    if (!isset($menu[$cat_it])) continue; // Salta se vuota
    echo '<h2 class="category" data-it="'.htmlspecialchars($cat_it).'" data-en="'.htmlspecialchars($cat_en).'">'.htmlspecialchars($cat_it).'</h2>';
    foreach ($menu[$cat_it] as $r) :
?>
  <div class="dish">
    <?php if ($r['immagine'] && file_exists($upload_dir . $r['immagine'])): ?>
      <img src="<?= $upload_dir . $r['immagine'] ?>" alt="<?= htmlspecialchars($r['nome_it']) ?>" class="dish-img">
    <?php else: ?>
      <img src="dashboard/menu/image/default.jpg" alt="Piatto" class="dish-img">
    <?php endif; ?>
    <div class="dish-info">
      <div class="dish-name" data-it="<?= htmlspecialchars($r['nome_it']) ?>" data-en="<?= htmlspecialchars($r['nome_en'] ?: $r['nome_it']) ?>"><?= htmlspecialchars($r['nome_it']) ?></div>
      <?php if(!empty($r['descrizione_it'])): ?>
        <div class="dish-desc" data-it="<?= htmlspecialchars($r['descrizione_it']) ?>" data-en="<?= htmlspecialchars($r['descrizione_en']) ?>"><?= htmlspecialchars($r['descrizione_it']) ?></div>
      <?php endif; ?>
      <?php if(!empty($r['allergeni_it'])): ?>
        <div class="allergens" data-it="<?= htmlspecialchars($r['allergeni_it']) ?>" data-en="<?= htmlspecialchars($r['allergeni_en']) ?>">
          <strong>Allergeni:</strong> <?= htmlspecialchars($r['allergeni_it']) ?>
        </div>
      <?php endif; ?>
    </div>
    <span class="price"><?= htmlspecialchars($r['prezzo']) ?></span>
  </div>
<?php
    endforeach;
endforeach;
?>
</main>

<!-- NOTE FINALI -->
<section class="menu-notes">
  <p data-it="💶 Coperto: €3,00 a persona" data-en="💶 Cover charge: €3.00 per person">💶 Coperto: €3,00 a persona</p>
  <p data-it="🌾 Menù gluten free disponibile su richiesta (maggiorazione applicata)" data-en="🌾 Gluten-free menu available on request (extra charge applies)">🌾 Menù gluten free disponibile su richiesta (maggiorazione applicata)</p>
  <p data-it="⚠️ Allergeni: consulta i simboli indicati accanto ai piatti o chiedi al personale." data-en="⚠️ Allergens: check the symbols next to dishes or ask our staff.">⚠️ Allergeni: consulta i simboli indicati accanto ai piatti o chiedi al personale.</p>
</section>

<!-- Lightbox -->
<div class="lightbox" id="lightbox">
  <img src="" alt="Ingrandimento piatto">
</div>

<script>
// Traduzione EN/IT
let lang = 'it';
document.getElementById('toggleLang').addEventListener('click', () => {
    lang = (lang === 'it') ? 'en' : 'it';
    document.querySelectorAll('[data-it]').forEach(el => {
        el.textContent = el.getAttribute('data-' + lang);
    });
});

// Lightbox immagini
const lightbox = document.getElementById('lightbox');
document.querySelectorAll('.dish-img').forEach(img => {
    img.addEventListener('click', () => {
        lightbox.style.display = 'flex';
        lightbox.querySelector('img').src = img.src;
    });
});
lightbox.addEventListener('click', () => { lightbox.style.display = 'none'; });
</script>

</body>
</html>
