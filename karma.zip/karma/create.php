<?php
/*require 'config.php';

$username = 'Admin';
$password = 'password123'; // inserisci la password desiderata
$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $hash);
$stmt->execute();

if ($stmt->affected_rows === 1) {
    echo "Utente creato con successo!";
} else {
    echo "Errore nella creazione dell'utente.";
}*/
?>
